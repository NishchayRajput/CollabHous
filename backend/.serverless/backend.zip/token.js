// function extractTokenValue(tokenString) {
//     const tokenIndex = tokenString.indexOf('token=');

//     if (tokenIndex !== -1) {
//       // Extract the substring starting from 'token=' and up to the end of the string
//       const tokenValue = tokenString.substring(tokenIndex + 6);
//       return tokenValue;
//     } else {
//       return null; // 'token=' not found in the string
//     }
//   }

// module.exports = extractTokenValue;